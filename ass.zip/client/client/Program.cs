﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Security;

namespace Client
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("mohame mosaad samier");
            Console.WriteLine("IS");
           Console.WriteLine("sec4");


                IPAddress host = IPAddress.Parse("127.0.0.1");
                IPEndPoint iep = new IPEndPoint(host, 8000);
                Socket new_cle = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                Console.WriteLine("getting file---");
                new_cle.Connect(iep);
                byte[] c_Data = new byte[1024 * 5000];

                int receivedBytesLen = new_cle.Receive(c_Data);
                int f_NameLen = BitConverter.ToInt32(c_Data, 0);
                string file_name = Encoding.ASCII.GetString(c_Data, 4, f_NameLen);
                BinaryWriter bWrite = new BinaryWriter(File.Open( file_name, FileMode.Append));
                bWrite.Write(c_Data, 4 + f_NameLen, receivedBytesLen - 4 - f_NameLen);
                bWrite.Close();
                new_cle.Shutdown(SocketShutdown.Both);
                new_cle.Close();



            }
           
        }
} 
