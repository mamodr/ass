﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace Server1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("mohame mosaad samier");
            Console.WriteLine("IS");
            Console.WriteLine("sec4");

                IPEndPoint iep = new IPEndPoint(IPAddress.Any, 8000);
                Socket new_ser = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                new_ser.Bind(iep);
                new_ser.Listen(100);
                Console.WriteLine("setting file---");
                Socket new_cle = new_ser.Accept();


                string file_name = Console.ReadLine(); ;

                byte[] f_namebyte = Encoding.ASCII.GetBytes(file_name);
                byte[] f_NameLen = BitConverter.GetBytes(f_namebyte.Length);
                byte[] f_Data = File.ReadAllBytes(file_name);
                byte[] c_Data = new byte[4 + f_namebyte.Length + f_Data.Length];
                f_NameLen.CopyTo(c_Data, 0);
                f_namebyte.CopyTo(c_Data, 4);
                f_Data.CopyTo(c_Data, 4 + f_namebyte.Length);
                new_cle.Send(c_Data);


                new_cle.Shutdown(SocketShutdown.Both);
                new_cle.Close();



        }
    }
}